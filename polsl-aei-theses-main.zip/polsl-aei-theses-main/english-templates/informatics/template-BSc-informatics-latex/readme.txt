Single-file directory holds a template in a single file (main.tex).
Multi-file directory holds a template in separate files for each chapter.
Both templates generate exactly the same output file.
