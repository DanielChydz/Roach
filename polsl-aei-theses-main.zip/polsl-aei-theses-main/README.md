# polsl-aei-theses

![Politechnika Śląska](politechnika_sl_logo_poziom_pl_rgb.png)

[PL] 🇵🇱 LaTeXowe szablony pracy dyplomowej inżynierskiej i magisterskiej na Wydziale Automatyki, Elektroniki i Informatyki Politechniki Śląskiej

[EN] 🇬🇧󠁧󠁢󠁥󠁮󠁧󠁿 LaTeX templates of an engineer (BSc) and master (MSc) thesis at the Faculty of Automatic Control, Electronics, and Computer Science at the Silesian University of Technology 

